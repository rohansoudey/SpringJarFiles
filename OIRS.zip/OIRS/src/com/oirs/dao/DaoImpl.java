package com.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.oirs.bean.User;
import com.oirs.dbutil.DBConnector;
import com.oirs.dbutil.IQueryMapper;

public class DaoImpl implements IDao {

	@Override
	public boolean checkLogin(User user) {
		
		boolean b = false;
		try {
			Connection con=DBConnector.getConnected();
		
			PreparedStatement ps=con.prepareStatement(IQueryMapper.lOGIN_QUERY);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			b=ps.execute();
		} catch (SQLException e) {
			
			
		}
		
		return b;
	}



}
