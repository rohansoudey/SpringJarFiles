package com.oirs.dao;

import com.oirs.bean.User;

public interface IDao {
	
	public boolean checkLogin(User user);

}
