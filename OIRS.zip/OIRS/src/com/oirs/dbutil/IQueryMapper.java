package com.oirs.dbutil;

public interface IQueryMapper {
	
	public static final String lOGIN_QUERY="select user_id,password from user1 where username=? and password =?";
	

}
